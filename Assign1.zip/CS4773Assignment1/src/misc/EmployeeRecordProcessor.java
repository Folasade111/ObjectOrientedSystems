package misc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class EmployeeRecordProcessor {
	private static int sumofEmployeeAges = 0;
	private static  int countforCommissionemployees = 0;
	private static double sumofEmployeeComissions = 0;
	private static int countforHourlyEmployees = 0;
	private static double sumofHourlyEmployeePay = 0;
	private static int countforSalaryEmployees = 0;
	private static double sumofSalaryEmployeePay = 0;
	private static String [] firstNames;
	private static String [] lastNames;
	private static int [] age;
	private static String Employeedata;
	private static String [] employeeType;
	private static double [] employeePay;
	private static Scanner scanner;
	private static String [] EmployeeRecordValues; 
	private static HashMap<String, Integer> firstNameandNoofPeopleSharingIt;
	private static HashMap<String,Integer> lastNameandPeopleSharingIt;
	private static StringBuffer EmployeeRecordOutput = new StringBuffer();
	private static String EmployeeRecordInput;
	private static int count=0,count2=0;
	private static float avgEmployeeAges;
	private static double avgofEmployeeComissions,avgofHourlyEmployeePay
	,avgofSalaryEmployeePay;

	/** 
	 * processEmployeeRecordsFile is a method that reads the employee records 
	 * from the data file and calls all the other methods to process the files 
	 * it is also used by TestRecordProcessor for unit testing
	 * @param AllEmployeedataFile is the employee data file that we read the information to be
	 * processed from
	 * @return a string containing the employee data that has been formatted
	 * it also contains the average ages, pays of the employees and also 
	 * the amount of people sharing the same last names and first names
	 */
	public static String processEmployeeRecordsFile(String AllEmployeedataFile){
		CreateRecordArrays(AllEmployeedataFile);
		sortLastNames(AllEmployeedataFile);
		if(count == 0){
			System.err.println("No records found in data file");
			scanner.close();
			return null;
		}
		CalculatesumofEmployeeAges();
		calculatesumofemployeecomission();
		calculatesumofhourlyemployeepay();
		calculatesumofSalaryemployeepay();
		calculateaverageEmployeeAges();
		calculateavgEmployeeComissions();
		calculateavgHourlyEmployeepay();
		calculateavgSalaryEmployeepay();
		FormatOutputString();
		AppendAverageAgetoOutputString();
		AppendAverageEmployeeComissionstoOutputString();
		AppendAveragehourlywagetoOutputString();
		AppendAverageSalarytoOutputString();
		AppendFirstNameswithNumberofPeoplesharingit();
		AppendLastNameswithNumberofPeoplesharingit();
		closeScanner();
		return EmployeeRecordOutput.toString();
	}

	public static void CreateRecordArrays(String AllEmployeedataFile){
		scanner = checkforemptyFile(AllEmployeedataFile);
		count = 0;
		while(scanner.hasNextLine()){
			Employeedata = scanner.nextLine();

			if(Employeedata.length() > 0)
				count++;
		}
		firstNames = new String[count];
		lastNames = new String[count];
		age = new int[count];
		employeeType = new String[count];
		employeePay = new double[count];

		closeScanner();
	}
	private static String[] splitRecordString( String S){
		String[] splittedrecord;
		splittedrecord= S.split(",");
		return splittedrecord;
	}
	private static void sortLastNames(String AllEmployeedataFile){
		scanner = checkforemptyFile(AllEmployeedataFile);
		count =0;
		while(scanner.hasNextLine()){
			EmployeeRecordInput = scanner.nextLine();
			if(EmployeeRecordInput.length() > 0){
				EmployeeRecordValues= splitRecordString(EmployeeRecordInput);
				count2 = 0; 
				for(;count2 < lastNames.length; count2++) {
					if(lastNames[count2] == null)
						break;
					if(lastNames[count2].compareTo(EmployeeRecordValues[1]) > 0) {
						for(int i = count; i > count2; i--) {
							firstNames[i] = firstNames[i - 1];
							lastNames[i] = lastNames[i - 1];
							age[i] = age[i - 1];
							employeeType[i] = employeeType[i - 1];
							employeePay[i] = employeePay[i - 1];
						}
						break;
					}
				}

				firstNames[count2] = EmployeeRecordValues[0];
				lastNames[count2] = EmployeeRecordValues[1];
				employeeType[count2] = EmployeeRecordValues[3];
				parseEmployeeAgeandPay();
				count++;

			}
		}
	}

	private static void FormatOutputString(){
		EmployeeRecordOutput.append(String.format("# of people imported: %d\n", 
				firstNames.length));
		EmployeeRecordOutput.append(String.format("\n%-30s %s  %-12s %12s\n",
				"Person Name", "Age", "Emp. Type", "Pay"));
		for(int i = 0; i < 30; i++)
			EmployeeRecordOutput.append(String.format("-"));
		EmployeeRecordOutput.append(String.format(" ---  "));
		for(int i = 0; i < 12; i++)
			EmployeeRecordOutput.append(String.format("-"));
		EmployeeRecordOutput.append(String.format(" "));
		for(int i = 0; i < 12; i++)
			EmployeeRecordOutput.append(String.format("-"));
		EmployeeRecordOutput.append(String.format("\n"));
		for(int i = 0; i < firstNames.length; i++) {
			EmployeeRecordOutput.append(String.format("%-30s %-3d  %-12s $%12.2f\n", 
					firstNames[i] + " " + lastNames[i], age[i]
							, employeeType[i], employeePay[i]));
		}

	}
	private static void parseEmployeeAgeandPay() throws RuntimeException{
		try {
			age[count2] = Integer.parseInt(EmployeeRecordValues[2]);
			employeePay[count2] = Double.parseDouble(EmployeeRecordValues[4]);
		} catch(Exception e) {
			throw new RuntimeException();

		}
	}
	private static void CalculatesumofEmployeeAges(){
		for(int i = 0; i < firstNames.length; i++) {
			sumofEmployeeAges += age[i];
		}
	}
	private static void calculatesumofemployeecomission(){
		for(int j = 0; j< firstNames.length;j++){
			if(employeeType[j].equals("Commission")) {
				sumofEmployeeComissions += employeePay[j];
				countforCommissionemployees++;
			} 
		}
	}
	private static void calculatesumofhourlyemployeepay(){
		for(int k = 0 ; k< firstNames.length ; k++){
			if(employeeType[k].equals("Hourly")) {
				sumofHourlyEmployeePay += employeePay[k];
				countforHourlyEmployees++;
			} 
		}
	}
	private static void calculatesumofSalaryemployeepay(){
		for(int i =0 ; i < firstNames.length;i++){
			if(employeeType[i].equals("Salary")) {
				sumofSalaryEmployeePay += employeePay[i];
				countforSalaryEmployees++;
			}
		}
	}
	private static void calculateaverageEmployeeAges(){
		avgEmployeeAges = 0;
		avgEmployeeAges = (float) sumofEmployeeAges / firstNames.length;
	}
	private static void calculateavgEmployeeComissions(){
		avgofEmployeeComissions = 0;
		avgofEmployeeComissions = sumofEmployeeComissions / countforCommissionemployees;
	}
	private static void calculateavgHourlyEmployeepay(){
		avgofHourlyEmployeePay = 0;
		avgofHourlyEmployeePay = sumofHourlyEmployeePay / countforHourlyEmployees;
	}
	private static void calculateavgSalaryEmployeepay(){
		avgofSalaryEmployeePay = 0;
		avgofSalaryEmployeePay = sumofSalaryEmployeePay / countforSalaryEmployees;
	}


	private static void AppendAverageAgetoOutputString(){
		EmployeeRecordOutput.append(String.format("\nAverage age:         %12.1f\n",
				avgEmployeeAges));
	}
	private static void AppendAverageEmployeeComissionstoOutputString(){
		EmployeeRecordOutput.append(String.format("Average commission:  $%12.2f\n",
				avgofEmployeeComissions));
	}
	private static void AppendAveragehourlywagetoOutputString(){
		EmployeeRecordOutput.append(String.format("Average hourly wage: $%12.2f\n", 
				avgofHourlyEmployeePay));
	}
	private static void AppendAverageSalarytoOutputString(){
		EmployeeRecordOutput.append(String.format("Average salary:      $%12.2f\n", 
				avgofSalaryEmployeePay));
	}
	private static int CreateHashMapforfirstNamesandNoofPeopleThatShareIt(){
		firstNameandNoofPeopleSharingIt = new HashMap<String, Integer>();
		int countofpeoplesharinglastName = 0;
		for(int i = 0; i < firstNames.length; i++) {
			if(firstNameandNoofPeopleSharingIt.containsKey(firstNames[i])) {
				firstNameandNoofPeopleSharingIt.put(firstNames[i], firstNameandNoofPeopleSharingIt.get(firstNames[i]) + 1);
				countofpeoplesharinglastName++;

			} else {
				firstNameandNoofPeopleSharingIt.put(firstNames[i], 1);
			}
		}
		return countofpeoplesharinglastName;
	}


	private static void AppendFirstNameswithNumberofPeoplesharingit(){
		int Noofpeoplesharingfirstname = CreateHashMapforfirstNamesandNoofPeopleThatShareIt();
		EmployeeRecordOutput.append(String.format
				("\nFirst names with more than one person sharing it:\n"));
		if(Noofpeoplesharingfirstname > 0) {
			Set<String> set = firstNameandNoofPeopleSharingIt.keySet();
			for(String firstname : set) {
				if(firstNameandNoofPeopleSharingIt.get(firstname) > 1) {
					EmployeeRecordOutput.append(String.format("%s, "
							+ "# people with this name: %d\n", firstname, 
							firstNameandNoofPeopleSharingIt.get(firstname)));
				}
			}
		} else { 
			EmployeeRecordOutput.append(String.format("All first names are unique"));
		}
	}
	private static int CreateHashMapforLastNamesandNoofPeopleThatShareIt(){
		lastNameandPeopleSharingIt = new HashMap<String, Integer>();
		int countofpeoplesharinglastname = 0;
		for(int i = 0; i < lastNames.length; i++) {
			if(lastNameandPeopleSharingIt.containsKey(lastNames[i])) {
				lastNameandPeopleSharingIt.put(lastNames[i], lastNameandPeopleSharingIt.get(lastNames[i]) + 1);
				countofpeoplesharinglastname++;
			} else {
				lastNameandPeopleSharingIt.put(lastNames[i], 1);
			}
		}
		return countofpeoplesharinglastname;
	}
	private static void AppendLastNameswithNumberofPeoplesharingit (){
		int Noofpeoplesharinglastname = CreateHashMapforLastNamesandNoofPeopleThatShareIt();
		EmployeeRecordOutput.append(String.format
				("\nLast names with more than one person sharing it:\n"));
		if(Noofpeoplesharinglastname > 0) {
			Set<String> set = lastNameandPeopleSharingIt.keySet();
			for(String lastname : set) {
				if(lastNameandPeopleSharingIt.get(lastname) > 1) {
					EmployeeRecordOutput.append(String.format("%s, "
							+ "# people with this name: %d\n", lastname, 
							lastNameandPeopleSharingIt.get(lastname)));
				}
			}
		} else { 
			EmployeeRecordOutput.append(String.format("All last names are unique"));
		}

	}
	private static void closeScanner(){
		scanner.close();
	}
	private static Scanner checkforemptyFile(String AllEmployeedataFile){
		try {
			scanner = new Scanner(new File(AllEmployeedataFile));
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
			return null ;
		}
		return scanner;

	}

}
